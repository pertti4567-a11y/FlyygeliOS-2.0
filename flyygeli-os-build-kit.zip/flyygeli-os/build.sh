#!/usr/bin/env bash
# Flyygeli OS – ISO-rakennus. Aja Arch Linuxissa (tai Arch-kontissa): bash build.sh
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
WORK="${WORK:-$HOME/flyygeli-build}"
OUT="${OUT:-$HOME/flyygeli-out}"
PROFILE="$WORK/profile"

command -v pacman >/dev/null || { echo "Tarvitaan Arch Linux (pacman puuttuu)."; exit 1; }
sudo pacman -S --needed --noconfirm archiso

sudo rm -rf "$WORK"; mkdir -p "$PROFILE" "$OUT"
cp -r /usr/share/archiso/configs/releng/. "$PROFILE/"

if [ -n "${LITE:-}" ]; then
  grep -v -e '^#' -e '^$' "$HERE/packages.extra" | grep -v -x -e blender -e kdenlive -e krita -e inkscape >> "$PROFILE/packages.x86_64"
else
  grep -v -e '^#' -e '^$' "$HERE/packages.extra" >> "$PROFILE/packages.x86_64"
fi
# grml-zsh-config omistaa /etc/skel/.zshrc ja aiheuttaa tiedostokonfliktin
sed -i '/^grml-zsh-config$/d' "$PROFILE/packages.x86_64"

cp -r "$HERE/overlay/." "$PROFILE/"

# Flyygeli Shell (Quickshell) – jos pakettia ei löydy, käytetään Waybaria
if pacman -Si quickshell >/dev/null 2>&1; then
  echo quickshell >> "$PROFILE/packages.x86_64"
else
  echo "Huom: quickshell puuttuu repoista, käytetään Waybaria."
fi

sed -i 's/^iso_name=.*/iso_name="flyygeli-os"/; s/^iso_label=.*/iso_label="FLYYGELI_$(date +%Y%m)"/; s/^iso_publisher=.*/iso_publisher="Flyygeli OS"/; s/^iso_application=.*/iso_application="Flyygeli OS Live"/' "$PROFILE/profiledef.sh"
sed -i '/^file_permissions=(/a\["/etc/sudoers.d/10-flyygeli"]="0:0:440"' "$PROFILE/profiledef.sh"

mkdir -p "$PROFILE/airootfs/etc/systemd/system"
ln -sf /usr/lib/systemd/system/sddm.service "$PROFILE/airootfs/etc/systemd/system/display-manager.service"

HOOKS_FILE="$PROFILE/airootfs/etc/mkinitcpio.conf.d/archiso.conf"
[ -f "$HOOKS_FILE" ] && sed -i 's/ udev / udev plymouth /' "$HOOKS_FILE"

find "$PROFILE/grub" "$PROFILE/syslinux" "$PROFILE/efiboot" -type f -exec \
  sed -i 's/archisosearchuuid=%ARCHISO_UUID%/& quiet splash threadirqs/' {} +
sed -i '1i set color_normal=white/black\nset color_highlight=black/yellow\nset menu_color_normal=white/black\nset menu_color_highlight=black/yellow' "$PROFILE/grub/grub.cfg"

sudo mkarchiso -v -w "$WORK/work" -o "$OUT" "$PROFILE"
echo; echo "Valmis: $(ls "$OUT"/flyygeli-os-*.iso | tail -1)"
echo "Testaa: run_archiso -u -i <iso>   (QEMU, virtio-gpu suositeltava)"
