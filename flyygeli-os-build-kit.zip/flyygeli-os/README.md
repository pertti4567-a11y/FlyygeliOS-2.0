# Flyygeli OS – rakennuspaketti

1. Arch Linux -kone (tai Arch-kontti), noin 15 Gt vapaata levyä.
2. `bash build.sh`
3. ISO ilmestyy kansioon `~/flyygeli-out/`.
4. USB:lle: `sudo dd if=flyygeli-os-*.iso of=/dev/sdX bs=4M status=progress oflag=sync`

Live-käyttäjä: `flyygeli` (automaattikirjautuminen, sudo ilman salasanaa).
Pikanäppäimet: SUPER+Enter terminaali, SUPER+D käynnistin, SUPER+Q sulje, SUPER+1..8 työtilat.
Näppäinasettelu: fi + us (Alt+Shift vaihtaa).

Jos jokin paketti ei löydy (esim. ttf-cormorant), poista se tiedostosta packages.extra.
Vital ja Surge XT lisätään jälkikäteen AURista.

## Rakennus ilman Arch-konetta (GitHub Actions)
1. Luo GitHubissa uusi yksityinen repo ja lataa tämän kansion sisältö sinne (myös `.github`).
2. Actions → "Build Flyygeli OS ISO" → Run workflow.
3. Valmis ISO löytyy ajon sivulta Artifacts-kohdasta (n. 20–40 min).
Kevyt versio jättää pois Blenderin, Kdenliven, Kritan ja Inkscapen, jotta levytila riittää.
Kevyt rakennus omalla koneella: `LITE=1 bash build.sh`

## Flyygeli Shell
Oma työpöytäkuori (Quickshell): yläpalkissa työtilat pianon koskettimina ja kello, alalaidassa sovelluskoskettimet.
Konfiguraatio: `~/.config/quickshell/flyygeli/shell.qml`. Jos Quickshell ei ole saatavilla, käytetään Waybaria.
