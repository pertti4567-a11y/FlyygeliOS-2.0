#!/bin/sh
# Käynnistää Flyygeli Shellin; jos Quickshell puuttuu, käytetään Waybaria.
if command -v quickshell >/dev/null 2>&1; then
  exec quickshell -c flyygeli
else
  exec waybar
fi
