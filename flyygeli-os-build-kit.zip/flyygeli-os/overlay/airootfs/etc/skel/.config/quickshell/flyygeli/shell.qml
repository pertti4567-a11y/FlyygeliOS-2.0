// Flyygeli Shell – oma työpöytäkuori (Quickshell + Hyprland)
import Quickshell
import Quickshell.Hyprland
import QtQuick

ShellRoot {
    id: root
    readonly property color ebony: "#0B0B0C"
    readonly property color brass: "#C9A24B"
    readonly property color ivory: "#F5F1E6"
    readonly property color wood:  "#6B4A2F"

    SystemClock { id: clock; precision: SystemClock.Minutes }

    Variants {
        model: Quickshell.screens

        Scope {
            id: scope
            required property var modelData

            // ---------- Yläpalkki: työtilat pianon koskettimina ----------
            PanelWindow {
                screen: scope.modelData
                anchors { top: true; left: true; right: true }
                implicitHeight: 34
                color: root.ebony

                Rectangle {
                    anchors.bottom: parent.bottom
                    width: parent.width
                    height: 1
                    color: root.brass
                }

                Row {
                    anchors.top: parent.top
                    anchors.left: parent.left
                    anchors.leftMargin: 16
                    spacing: 3

                    Repeater {
                        model: 8
                        Rectangle {
                            id: wsKey
                            required property int index
                            readonly property bool active: Hyprland.focusedWorkspace !== null
                                && Hyprland.focusedWorkspace.id === index + 1
                            width: 16
                            height: active ? 28 : 20
                            radius: 3
                            color: active ? root.brass : root.ivory
                            Behavior on height { NumberAnimation { duration: 220; easing.type: Easing.OutExpo } }
                            Behavior on color  { ColorAnimation  { duration: 180 } }
                            MouseArea {
                                anchors.fill: parent
                                onClicked: Hyprland.dispatch("workspace " + (wsKey.index + 1))
                            }
                        }
                    }
                }

                Text {
                    anchors.centerIn: parent
                    text: Qt.formatDateTime(clock.date, "hh:mm  ·  ddd d.M.")
                    color: root.brass
                    font.family: "Cormorant Garamond"
                    font.pixelSize: 19
                    font.bold: true
                }

                Text {
                    anchors.right: parent.right
                    anchors.rightMargin: 16
                    anchors.verticalCenter: parent.verticalCenter
                    text: "♪ Flyygeli OS"
                    color: ivoryDim
                    font.family: "Cormorant Garamond"
                    font.pixelSize: 15
                    font.italic: true
                    readonly property color ivoryDim: "#B9B4A6"
                }
            }

            // ---------- Alapalkki: sovellukset koskettimina ----------
            PanelWindow {
                screen: scope.modelData
                anchors { bottom: true }
                margins { bottom: 12 }
                exclusionMode: ExclusionMode.Ignore
                implicitWidth: dockRow.implicitWidth + 28
                implicitHeight: 86
                color: "transparent"

                Rectangle {
                    anchors.fill: parent
                    radius: 12
                    color: Qt.rgba(0.043, 0.043, 0.047, 0.94)
                    border.width: 1
                    border.color: root.brass
                }

                Row {
                    id: dockRow
                    anchors.centerIn: parent
                    spacing: 4

                    Repeater {
                        model: [
                            { label: "Pääte",   cmd: ["kitty"] },
                            { label: "Tiedostot", cmd: ["thunar"] },
                            { label: "Netti",   cmd: ["firefox"] },
                            { label: "Ardour",  cmd: ["ardour"] },
                            { label: "Nuotit",  cmd: ["musescore"] },
                            { label: "Qpwgraph", cmd: ["qpwgraph"] }
                        ]
                        Item {
                            id: slot
                            required property var modelData
                            width: 64
                            height: 64

                            Rectangle {
                                anchors.top: parent.top
                                anchors.left: parent.left
                                anchors.right: parent.right
                                height: ma.pressed ? 56 : 64
                                radius: 5
                                color: ma.containsMouse ? "#FFFFFF" : root.ivory
                                Behavior on height { NumberAnimation { duration: 90 } }

                                Rectangle {
                                    anchors.bottom: parent.bottom
                                    anchors.left: parent.left
                                    anchors.right: parent.right
                                    height: 4
                                    radius: 2
                                    color: root.brass
                                }
                                Text {
                                    anchors.centerIn: parent
                                    text: slot.modelData.label
                                    color: root.ebony
                                    font.family: "Inter"
                                    font.pixelSize: 11
                                }
                                MouseArea {
                                    id: ma
                                    anchors.fill: parent
                                    hoverEnabled: true
                                    onClicked: Quickshell.execDetached(slot.modelData.cmd)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
